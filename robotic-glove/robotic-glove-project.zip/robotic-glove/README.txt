# Low-Cost Robotic Assistance Glove: code

Education and research prototype. Not a medical device. Test on the artificial finger and artificial hand only.

firmware/servo_calibration/servo_calibration.ino  Stage 1 tool: move one servo slowly to typed angles
firmware/robotic_glove/robotic_glove.ino          Full program: 2 servos, buttons, E-stop sense, USB protocol
pc_app/glove_control.py                           PC control panel (Python 3.8+, Tkinter, pyserial)

Arduino: open each .ino in Arduino IDE 2, board "Arduino Nano", processor ATmega328P
(use "Old Bootloader" if upload fails). Set your calibration angles in section 2 first.

PC app:  pip install pyserial   then   python glove_control.py
Choose "SIMULATOR (no hardware)" to try it without the Arduino.

The full build guide (mechanics, wiring, stages, budget, testing) is index.html in this folder.
